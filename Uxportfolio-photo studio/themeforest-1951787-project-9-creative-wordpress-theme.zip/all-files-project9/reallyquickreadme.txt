Just a couple things:

1.  Be sure to upload the theme itself - entitled:  "project9".  Do not upload the folder that is entitled:  "all-files-project9". 

2.  You can find the icons used in the demo at http://glyphicons.com/ - they are free, and available for use.

3.  It would be really appreciated if you can have a moment to go rate the theme.  It's really hard to get theme ratings…Go to Downloads, and next to the theme there are some stars… :)
