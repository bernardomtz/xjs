<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar One') ) : ?><?php endif; ?>			
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar Two') ) : ?><?php endif; ?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar Three') ) : ?><?php endif; ?>	
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar Four') ) : ?><?php endif; ?>	
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar Five') ) : ?><?php endif; ?>