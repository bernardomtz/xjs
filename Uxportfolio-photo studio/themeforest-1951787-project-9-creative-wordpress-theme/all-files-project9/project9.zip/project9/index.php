<?php get_header(); ?>

<!-- BEGIN loop -->
<?php get_template_part( 'loop' ); ?> 
<!-- END loop -->

<?php get_footer(); ?>