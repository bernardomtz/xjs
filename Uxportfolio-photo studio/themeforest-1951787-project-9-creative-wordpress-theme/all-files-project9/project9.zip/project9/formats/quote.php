<div class="quote-wrap">
<?php the_content(); ?>
</div>

<div class="blog-wrap">
<h4 class="latest-blog"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a><span class="video standard"><img src="<?php echo get_template_directory_uri(); ?>/framework/images/quote.png"></span></h4>
</div>